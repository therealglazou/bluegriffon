#!/bin/sh

rm -fr opt/bluegriffon
cd opt; bzip2 -dc ~/bin/opt/trunk/dist/*.bz2 | tar xf -; cd ..

rm -fr control.tar.gz data.tar.gz
cd DEBIAN; tar cvfz ../control.tar.gz .; cd ..
tar cvfz data.tar.gz ./usr ./opt

rm ../bluegriffon_2.2-1ubuntu1_i386.deb
ar r  ../bluegriffon_2.2-1ubuntu1_i386.deb debian-binary control.tar.gz data.tar.gz

# sudo apt-get --purge remove bluegriffon
# sudo dpkg -i deb_file
